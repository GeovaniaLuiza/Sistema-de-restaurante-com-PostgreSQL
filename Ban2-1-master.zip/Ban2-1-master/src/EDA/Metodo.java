/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EDA;

/**
 *
 * @author Gui
 */
public class Metodo {
    private int idMetodo;
    private String Nome;


    public Metodo(int idMetodo, String Nome){
            this.idMetodo = idMetodo;
            this.Nome = Nome;
    }

    /**
     * @return the idMetodo
     */
    public int getIdMetodo() {
        return idMetodo;
    }

    /**
     * @param idMetodo the idMetodo to set
     */
    public void setIdMetodo(int idMetodo) {
        this.idMetodo = idMetodo;
    }

    /**
     * @return the Nome
     */
    public String getNome() {
        return Nome;
    }

    /**
     * @param Nome the Nome to set
     */
    public void setNome(String Nome) {
        this.Nome = Nome;
    }
}