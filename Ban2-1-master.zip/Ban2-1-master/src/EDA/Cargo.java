/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EDA;

/**
 *
 * @author Gui
 */
public class Cargo {
    private int codCargo;
    private String Nome;
    private long taxa, salario;


    public Cargo(int codCargo, String Nome, long taxa, long salario){
            this.codCargo = codCargo;
            this.Nome = Nome;
            this.taxa = taxa;
            this.salario = salario;
    }

    /**
     * @return the codCargo
     */
    public int getCodCargo() {
        return codCargo;
    }

    /**
     * @param codCargo the codCargo to set
     */
    public void setCodCargo(int codCargo) {
        this.codCargo = codCargo;
    }

    /**
     * @return the Nome
     */
    public String getNome() {
        return Nome;
    }

    /**
     * @param Nome the Nome to set
     */
    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    /**
     * @return the taxa
     */
    public long getTaxa() {
        return taxa;
    }

    /**
     * @param taxa the taxa to set
     */
    public void setTaxa(long taxa) {
        this.taxa = taxa;
    }

    /**
     * @return the salario
     */
    public long getSalario() {
        return salario;
    }

    /**
     * @param salario the salario to set
     */
    public void setSalario(long salario) {
        this.salario = salario;
    }
}
