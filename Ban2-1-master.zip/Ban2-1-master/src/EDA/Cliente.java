/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EDA;

/**
 *
 * @author Gui
 */
public class Cliente {
    private long cpf, Pedido_Comanda, buffet ;
    private String Nome;


    public Cliente(int codProduto, String Nome){
            this.cpf = cpf;
            this.Pedido_Comanda = Pedido_Comanda;
            this.buffet = buffet; 
            this.Nome = Nome;
    }

    /**
     * @return the cpf
     */
    public long getCpf() {
        return cpf;
    }

    /**
     * @param cpf the cpf to set
     */
    public void setCpf(long cpf) {
        this.cpf = cpf;
    }

    /**
     * @return the Pedido_Comanda
     */
    public long getPedido_Comanda() {
        return Pedido_Comanda;
    }

    /**
     * @param Pedido_Comanda the Pedido_Comanda to set
     */
    public void setPedido_Comanda(long Pedido_Comanda) {
        this.Pedido_Comanda = Pedido_Comanda;
    }

    /**
     * @return the buffet
     */
    public long getBuffet() {
        return buffet;
    }

    /**
     * @param buffet the buffet to set
     */
    public void setBuffet(long buffet) {
        this.buffet = buffet;
    }

    /**
     * @return the Nome
     */
    public String getNome() {
        return Nome;
    }

    /**
     * @param Nome the Nome to set
     */
    public void setNome(String Nome) {
        this.Nome = Nome;
    }
    
}
