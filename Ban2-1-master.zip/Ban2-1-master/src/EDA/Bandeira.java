/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EDA;

/**
 *
 * @author Gui
 */
public class Bandeira {
    private int idBandeira;
    private String Nome;


    public Bandeira(int idBandeira, String Nome){
            this.idBandeira = idBandeira;
            this.Nome = Nome;
    }

    /**
     * @return the idBandeira
     */
    public int getIdBandeira() {
        return idBandeira;
    }

    /**
     * @param idBandeira the idBandeira to set
     */
    public void setIdBandeira(int idBandeira) {
        this.idBandeira = idBandeira;
    }

    /**
     * @return the Nome
     */
    public String getNome() {
        return Nome;
    }

    /**
     * @param Nome the Nome to set
     */
    public void setNome(String Nome) {
        this.Nome = Nome;
    }
}