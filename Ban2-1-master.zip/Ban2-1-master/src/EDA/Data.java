/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EDA;

import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Date;
/**
 *
 * @author Gui
 */
public class Data {
  
    public Data(String dateInString ){
           
            
     } 
            
    static public  Date convertData(String dateInString){
             SimpleDateFormat formatter = new SimpleDateFormat("ddMMyyyy");
           try {

            Date date = formatter.parse(dateInString);
            System.out.println(formatter.format(date));
               return date;
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
     
}
   
}
