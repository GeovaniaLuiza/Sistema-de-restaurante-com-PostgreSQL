/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EDA;

/**
 *
 * @author Gui
 */
public class Restaurante{
    private int codRestaurante, capacidade, cep;
    private String nome, endereco;


    public Restaurante(int codRestaurante, int capacidade, int cep, String nome, String endereco){
            this.codRestaurante = codRestaurante;
            this.capacidade = capacidade;
            this.cep = cep;
            this.nome = nome;
            this.endereco = endereco;
    }

    /**
     * @return the codRestaurante
     */
    public int getCodRestaurante() {
        return codRestaurante;
    }

    /**
     * @param codRestaurante the codRestaurante to set
     */
    public void setCodRestaurante(int codRestaurante) {
        this.codRestaurante = codRestaurante;
    }

    /**
     * @return the capacidade
     */
    public int getCapacidade() {
        return capacidade;
    }

    /**
     * @param capacidade the capacidade to set
     */
    public void setCapacidade(int capacidade) {
        this.capacidade = capacidade;
    }

    /**
     * @return the cep
     */
    public int getCep() {
        return cep;
    }

    /**
     * @param cep the cep to set
     */
    public void setCep(int cep) {
        this.cep = cep;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the endereco
     */
    public String getEndereco() {
        return endereco;
    }

    /**
     * @param endereco the endereco to set
     */
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
}