/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EDA;

import java.time.LocalDate;

/**
 *
 * @author Gui
 */
public class Reserva {
    private int idreserva, quantidade;
    private long Cliente_Cpf;
    private LocalDate data_2;


    public Reserva(int idreserva, long Cliente_Cpf, int quantidade, LocalDate data_2){
            this.idreserva = idreserva;
            this.quantidade = quantidade;
            this.Cliente_Cpf= Cliente_Cpf;
            this.data_2= data_2;
    }

    /**
     * @return the idreserva
     */
    public int getIdreserva() {
        return idreserva;
    }

    /**
     * @param idreserva the idreserva to set
     */
    public void setIdreserva(int idreserva) {
        this.idreserva = idreserva;
    }

    /**
     * @return the quantidade
     */
    public int getQuantidade() {
        return quantidade;
    }

    /**
     * @param quantidade the quantidade to set
     */
    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    /**
     * @return the Cliente_Cpf
     */
    public long getCliente_Cpf() {
        return Cliente_Cpf;
    }

    /**
     * @param Cliente_Cpf the Cliente_Cpf to set
     */
    public void setCliente_Cpf(long Cliente_Cpf) {
        this.Cliente_Cpf = Cliente_Cpf;
    }

       public LocalDate getData_2() {
        return data_2;
    }

    public void setData_2(LocalDate data_2) {
        this.data_2 = data_2;
    }
    
}
