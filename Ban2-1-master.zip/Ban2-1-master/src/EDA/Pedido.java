/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EDA;

/**
 *
 * @author Gui
 */
public class Pedido {
    private int Comanda,valorProdutos,mesa;
    private long funcionario_cpf, Cliente_cpf;


    public Pedido(int Comanda, int valorProdutos, long Cliente_cpf, long funcionario_cpf,int mesa ){
            this.Comanda = Comanda;
            this.valorProdutos = valorProdutos;
            this.Cliente_cpf = Cliente_cpf;
            this.funcionario_cpf = funcionario_cpf;
            this.mesa = mesa;
    }       

    /**
     * @return the Comanda
     */
    public int getComanda() {
        return Comanda;
    }

    /**
     * @param Comanda the Comanda to set
     */
    public void setComanda(int Comanda) {
        this.Comanda = Comanda;
    }

    /**
     * @return the valorProdutos
     */
    public int getValorProdutos() {
        return valorProdutos;
    }

    /**
     * @param valorProdutos the valorProdutos to set
     */
    public void setValorProdutos(int valorProdutos) {
        this.valorProdutos = valorProdutos;
    }

    /**
     * @return the mesa
     */
    public int getMesa() {
        return mesa;
    }

    /**
     * @param mesa the mesa to set
     */
    public void setMesa(int mesa) {
        this.mesa = mesa;
    }

    /**
     * @return the funcionario_cpf
     */
    public long getFuncionario_cpf() {
        return funcionario_cpf;
    }

    /**
     * @param funcionario_cpf the funcionario_cpf to set
     */
    public void setFuncionario_cpf(long funcionario_cpf) {
        this.funcionario_cpf = funcionario_cpf;
    }

    /**
     * @return the Cliente_cpf
     */
    public long getCliente_cpf() {
        return Cliente_cpf;
    }

    /**
     * @param Cliente_cpf the Cliente_cpf to set
     */
    public void setCliente_cpf(long Cliente_cpf) {
        this.Cliente_cpf = Cliente_cpf;
    }

}