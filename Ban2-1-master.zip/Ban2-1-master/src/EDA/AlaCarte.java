/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EDA;

/**
 *
 * @author Gui
 */
public class AlaCarte {
    private int idalaCarte, Pedido_Comanda, alaCarte_FKIndex1;


    public AlaCarte(int idalaCarte, int Pedido_Comanda,int alaCarte_FKIndex1 ){
            this.idalaCarte = idalaCarte;
            this.Pedido_Comanda = Pedido_Comanda;
            this.alaCarte_FKIndex1= alaCarte_FKIndex1;
    }

    /**
     * @return the idalaCarte
     */
    public int getIdalaCarte() {
        return idalaCarte;
    }

    /**
     * @param idalaCarte the idalaCarte to set
     */
    public void setIdalaCarte(int idalaCarte) {
        this.idalaCarte = idalaCarte;
    }

    /**
     * @return the Pedido_Comanda
     */
    public int getPedido_Comanda() {
        return Pedido_Comanda;
    }

    /**
     * @param Pedido_Comanda the Pedido_Comanda to set
     */
    public void setPedido_Comanda(int Pedido_Comanda) {
        this.Pedido_Comanda = Pedido_Comanda;
    }

    /**
     * @return the alaCarte_FKIndex1
     */
    public int getAlaCarte_FKIndex1() {
        return alaCarte_FKIndex1;
    }

    /**
     * @param alaCarte_FKIndex1 the alaCarte_FKIndex1 to set
     */
    public void setAlaCarte_FKIndex1(int alaCarte_FKIndex1) {
        this.alaCarte_FKIndex1 = alaCarte_FKIndex1;
    }


}