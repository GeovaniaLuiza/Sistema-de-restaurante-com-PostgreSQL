/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EDA;
import java.time.LocalDate;

/**
 *
 * @author Gui
 */
public class Funcionario {
    private long cpf;
    private int restaurante_codRestaurante, cargo_codcargo, conta;
    private String nome ;
    private LocalDate dataContratacao, dataDemissao;
    
    
    public Funcionario(long cpf, String nome, int conta, int cargo_codcargo, LocalDate dataContratacao, LocalDate dataDemissao,int restaurante_codRestaurante){
        this.cpf = cpf;
        this.restaurante_codRestaurante = restaurante_codRestaurante;
        this.cargo_codcargo = cargo_codcargo;
        this.conta = conta;
        this.nome = nome;
        this.dataContratacao = dataContratacao;
        this.dataDemissao = dataDemissao;
    }

    /**
     * @return the cpf
     */
    public long getCpf() {
        return cpf;
    }

    /**
     * @param cpf the cpf to set
     */
    public void setCpf(long cpf) {
        this.cpf = cpf;
    }

    /**
     * @return the restaurante_codRestaurante
     */
    public int getRestaurante_codRestaurante() {
        return restaurante_codRestaurante;
    }

    /**
     * @param restaurante_codRestaurante the restaurante_codRestaurante to set
     */
    public void setRestaurante_codRestaurante(int restaurante_codRestaurante) {
        this.restaurante_codRestaurante = restaurante_codRestaurante;
    }

    /**
     * @return the cargo_codcargo
     */
    public int getCargo_codcargo() {
        return cargo_codcargo;
    }

    /**
     * @param cargo_codcargo the cargo_codcargo to set
     */
    public void setCargo_codcargo(int cargo_codcargo) {
        this.cargo_codcargo = cargo_codcargo;
    }

    /**
     * @return the conta
     */
    public int getConta() {
        return conta;
    }

    /**
     * @param conta the conta to set
     */
    public void setConta(int conta) {
        this.conta = conta;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the dataContratacao
     */
    public LocalDate getDataContratacao() {
        return dataContratacao;
    }

    /**
     * @param dataContratacao the dataContratacao to set
     */
    public void setDataContratacao(LocalDate dataContratacao) {
        this.dataContratacao = dataContratacao;
    }

    /**
     * @return the dataDemissao
     */
    public LocalDate getDataDemissao() {
        return dataDemissao;
    }

    /**
     * @param dataDemissao the dataDemissao to set
     */
    public void setDataDemissao(LocalDate dataDemissao) {
        this.dataDemissao = dataDemissao;
    }
}