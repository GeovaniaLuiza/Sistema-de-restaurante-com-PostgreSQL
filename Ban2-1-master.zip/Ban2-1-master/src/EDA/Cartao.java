/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EDA;

/**
 *
 * @author Gui
 */
public class Cartao {
    private long nunCartao;
    private int Metodo_idMetodo,Bandeira_idBandeira;


    public Cartao(long nunCartao, int Metodo_idMetodo, int Bandeira_idBandeira){
            this.nunCartao = nunCartao;
            this.Metodo_idMetodo = Metodo_idMetodo;
            this.Bandeira_idBandeira= Bandeira_idBandeira;
    }

    /**
     * @return the nunCartao
     */
    public long getNunCartao() {
        return nunCartao;
    }

    /**
     * @param nunCartao the nunCartao to set
     */
    public void setNunCartao(long nunCartao) {
        this.nunCartao = nunCartao;
    }

    /**
     * @return the Metodo_idMetodo
     */
    public int getMetodo_idMetodo() {
        return Metodo_idMetodo;
    }

    /**
     * @param Metodo_idMetodo the Metodo_idMetodo to set
     */
    public void setMetodo_idMetodo(int Metodo_idMetodo) {
        this.Metodo_idMetodo = Metodo_idMetodo;
    }

    /**
     * @return the Bandeira_idBandeira
     */
    public int getBandeira_idBandeira() {
        return Bandeira_idBandeira;
    }

    /**
     * @param Bandeira_idBandeira the Bandeira_idBandeira to set
     */
    public void setBandeira_idBandeira(int Bandeira_idBandeira) {
        this.Bandeira_idBandeira = Bandeira_idBandeira;
    }
    
}
