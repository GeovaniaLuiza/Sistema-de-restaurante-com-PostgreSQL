/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EDA;

/**
 *
 * @author Gui
 */
public class Pagamento {
    private long Cartao_numCartao , Cliente_cpf;
    private int Dinheiro_idDinheiro,Pedido_Comanda;


    public Pagamento(long Cartao_numCartao, long Cliente_cpf, int Dinheiro_idDinheiro, int Pedido_Comanda ){
            this.Cartao_numCartao = Cartao_numCartao;
            this.Cliente_cpf = Cliente_cpf;
            this.Dinheiro_idDinheiro= Dinheiro_idDinheiro;
            this.Pedido_Comanda = Pedido_Comanda;
    }

    /**
     * @return the Cartao_numCartao
     */
    public long getCartao_numCartao() {
        return Cartao_numCartao;
    }

    /**
     * @param Cartao_numCartao the Cartao_numCartao to set
     */
    public void setCartao_numCartao(long Cartao_numCartao) {
        this.Cartao_numCartao = Cartao_numCartao;
    }

    /**
     * @return the Cliente_cpf
     */
    public long getCliente_cpf() {
        return Cliente_cpf;
    }

    /**
     * @param Cliente_cpf the Cliente_cpf to set
     */
    public void setCliente_cpf(long Cliente_cpf) {
        this.Cliente_cpf = Cliente_cpf;
    }

    /**
     * @return the Dinheiro_idDinheiro
     */
    public int getDinheiro_idDinheiro() {
        return Dinheiro_idDinheiro;
    }

    /**
     * @param Dinheiro_idDinheiro the Dinheiro_idDinheiro to set
     */
    public void setDinheiro_idDinheiro(int Dinheiro_idDinheiro) {
        this.Dinheiro_idDinheiro = Dinheiro_idDinheiro;
    }

    /**
     * @return the Pedido_Comanda
     */
    public int getPedido_Comanda() {
        return Pedido_Comanda;
    }

    /**
     * @param Pedido_Comanda the Pedido_Comanda to set
     */
    public void setPedido_Comanda(int Pedido_Comanda) {
        this.Pedido_Comanda = Pedido_Comanda;
    }


}