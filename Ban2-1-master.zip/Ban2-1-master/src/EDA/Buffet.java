/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EDA;

/**
 *
 * @author Gui
 */
public class Buffet {
    private int idbuffet, Pedido_Comanda, buffet ;
    private String Nome;


    public Buffet(int idbuffet, String Nome){
            this.idbuffet = idbuffet;
            this.Pedido_Comanda = Pedido_Comanda;
            this.buffet = buffet; 
            this.Nome = Nome;
    }

    /**
     * @return the idbuffet
     */
    public int getIdbuffet() {
        return idbuffet;
    }

    /**
     * @param idbuffet the idbuffet to set
     */
    public void setIdbuffet(int idbuffet) {
        this.idbuffet = idbuffet;
    }

    /**
     * @return the Pedido_Comanda
     */
    public int getPedido_Comanda() {
        return Pedido_Comanda;
    }

    /**
     * @param Pedido_Comanda the Pedido_Comanda to set
     */
    public void setPedido_Comanda(int Pedido_Comanda) {
        this.Pedido_Comanda = Pedido_Comanda;
    }

    /**
     * @return the buffet
     */
    public int getBuffet() {
        return buffet;
    }

    /**
     * @param buffet the buffet to set
     */
    public void setBuffet(int buffet) {
        this.buffet = buffet;
    }

    /**
     * @return the Nome
     */
    public String getNome() {
        return Nome;
    }

    /**
     * @param Nome the Nome to set
     */
    public void setNome(String Nome) {
        this.Nome = Nome;
    }

}

