/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EDA;

/**
 *
 * @author Gui
 */
public class Produto_has_Pedido {
    private int Produto_codProduto, Pedido_Comanda, Produto_has_Pedido_FKIndex1, Produto_has_Pedido_FKIndex2;


public Produto_has_Pedido(int Produto_codProduto, int Pedido_Comanda, int Produto_has_Pedido_FKIndex1, int Produto_has_Pedido_FKIndex2){
        this.Produto_codProduto = Produto_codProduto;
        this.Pedido_Comanda = Pedido_Comanda;
        this.Produto_has_Pedido_FKIndex1 = Produto_has_Pedido_FKIndex1;
        this.Produto_has_Pedido_FKIndex2 = Produto_has_Pedido_FKIndex2;
}

    /**
     * @return the Produto_codProduto
     */
    public int getProduto_codProduto() {
        return Produto_codProduto;
    }

    /**
     * @param Produto_codProduto the Produto_codProduto to set
     */
    public void setProduto_codProduto(int Produto_codProduto) {
        this.Produto_codProduto = Produto_codProduto;
    }

    /**
     * @return the Pedido_Comanda
     */
    public int getPedido_Comanda() {
        return Pedido_Comanda;
    }

    /**
     * @param Pedido_Comanda the Pedido_Comanda to set
     */
    public void setPedido_Comanda(int Pedido_Comanda) {
        this.Pedido_Comanda = Pedido_Comanda;
    }

    /**
     * @return the Produto_has_Pedido_FKIndex1
     */
    public int getProduto_has_Pedido_FKIndex1() {
        return Produto_has_Pedido_FKIndex1;
    }

    /**
     * @param Produto_has_Pedido_FKIndex1 the Produto_has_Pedido_FKIndex1 to set
     */
    public void setProduto_has_Pedido_FKIndex1(int Produto_has_Pedido_FKIndex1) {
        this.Produto_has_Pedido_FKIndex1 = Produto_has_Pedido_FKIndex1;
    }

    /**
     * @return the Produto_has_Pedido_FKIndex2
     */
    public int getProduto_has_Pedido_FKIndex2() {
        return Produto_has_Pedido_FKIndex2;
    }

    /**
     * @param Produto_has_Pedido_FKIndex2 the Produto_has_Pedido_FKIndex2 to set
     */
    public void setProduto_has_Pedido_FKIndex2(int Produto_has_Pedido_FKIndex2) {
        this.Produto_has_Pedido_FKIndex2 = Produto_has_Pedido_FKIndex2;
    }
}



