/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EDA;

/**
 *
 * @author Gui
 */
public class Delivery {
    private int iddelivery, Pedido_Comanda, cep, delivery_FkIndex1;
    private String Pedido_comanda, endereco;


    public Delivery(int iddelivery, int Pedido_Comanda, int cep, int delivery_FkIndex1, String Pedido_comanda, String endereco){
            this.iddelivery = iddelivery;
            this.Pedido_Comanda = Pedido_Comanda;
            this.cep = cep;
            this.delivery_FkIndex1= delivery_FkIndex1;
            this.Pedido_comanda = Pedido_comanda;
            this.endereco = endereco;
    }

    /**
     * @return the iddelivery
     */
    public int getIddelivery() {
        return iddelivery;
    }

    /**
     * @param iddelivery the iddelivery to set
     */
    public void setIddelivery(int iddelivery) {
        this.iddelivery = iddelivery;
    }

    /**
     * @return the Pedido_Comanda
     */
    public int getPedido_Comanda() {
        return Pedido_Comanda;
    }

    /**
     * @param Pedido_Comanda the Pedido_Comanda to set
     */
    public void setPedido_Comanda(int Pedido_Comanda) {
        this.Pedido_Comanda = Pedido_Comanda;
    }

    /**
     * @return the cep
     */
    public int getCep() {
        return cep;
    }

    /**
     * @param cep the cep to set
     */
    public void setCep(int cep) {
        this.cep = cep;
    }

    /**
     * @return the delivery_FkIndex1
     */
    public int getDelivery_FkIndex1() {
        return delivery_FkIndex1;
    }

    /**
     * @param delivery_FkIndex1 the delivery_FkIndex1 to set
     */
    public void setDelivery_FkIndex1(int delivery_FkIndex1) {
        this.delivery_FkIndex1 = delivery_FkIndex1;
    }

    /**
     * @return the Pedido_comanda
     */
    public String getPedido_comanda() {
        return Pedido_comanda;
    }

    /**
     * @param Pedido_comanda the Pedido_comanda to set
     */
    public void setPedido_comanda(String Pedido_comanda) {
        this.Pedido_comanda = Pedido_comanda;
    }

    /**
     * @return the endereco
     */
    public String getEndereco() {
        return endereco;
    }

    /**
     * @param endereco the endereco to set
     */
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

}