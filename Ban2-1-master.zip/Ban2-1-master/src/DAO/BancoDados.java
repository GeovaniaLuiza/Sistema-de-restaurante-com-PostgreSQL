package DAO;
import static DAO.BancoDados.c;
import EDA.Funcionario;
import EDA.Pedido;
import EDA.Pagamento;
import EDA.Reserva;
import EDA.Delivery;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 * @author UDESC
 */
public class BancoDados {
    static Connection c = null;
    
    private boolean conectar(){
        try {
            //Class.forName("org.postgresql.Driver");
            c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/restaurante",
                                            "postgres", "q1w2e3");
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println(e.getClass().getName()+": "+e.getMessage());
            return false;
        }
        return true;
    }
    
    
    public ArrayList<Funcionario> getFuncionarios(){
        if( !conectar() ) return null;
        ArrayList<Funcionario> resultado = new ArrayList();
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "SELECT * FROM funcionario";
            ResultSet rs = stmt.executeQuery( sql );
            while ( rs.next() ) {
                String lercpf = rs.getString("cpf");
                long cpf = Long.parseLong(lercpf);
                String  nome = rs.getString("nome");
                int  conta = rs.getInt("conta");
                int cargo_codcargo  = rs.getInt("cargo_codcargo");
                String lerdataContratacao = rs.getString("dataContratacao");
                LocalDate dataContratacao = LocalDate.parse(lerdataContratacao);
                
                String lerdataDemissao = rs.getString("datademissao");
                LocalDate dataDemissao;
                if(lerdataDemissao!=null){
                   dataDemissao = LocalDate.parse(lerdataDemissao); 
                }else{
                    dataDemissao=null;
                }
                
                
                int restaurante_codRestaurante = rs.getInt("restaurante_codRestaurante");
                resultado.add( new Funcionario(cpf, nome, conta, cargo_codcargo, dataContratacao, dataDemissao,restaurante_codRestaurante) );
            }
            rs.close();
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            e.printStackTrace();
            System.err.println( "ERRO DURANTE CONSULTA: getFuncionarios");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
        }
        return resultado;
    }
    
    public Funcionario getFuncionario(long cod){
        if( !conectar() ) return null;
        Funcionario resultado = null;
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "SELECT * FROM funcionario WHERE cpf = "+cod;
            ResultSet rs = stmt.executeQuery( sql );
            while ( rs.next() ) {
                        
                Long  cpf = Long.parseLong(rs.getString("cpf"));
                String  name = rs.getString("nome");
                int conta  = rs.getInt("conta");
                int cargo  = rs.getInt("cargo_codcargo");
                LocalDate dateCont;
                LocalDate dateDemi;
                //validacao se o campo data de contratacao é nulo
                if(rs.getString("dataContratacao")!=null){
                    dateCont = LocalDate.parse(rs.getString("dataContratacao"));
                }else{
                    dateCont= null;
                }         
                 //validacao se o campo data de demissao é nulo
                if(rs.getString("dataDemissao")!=null){
                    dateDemi = LocalDate.parse(rs.getString("dataDemissao"));
                }else{
                    dateDemi=null;
                }

                int restaurante_codRestaurante =  rs.getInt("restaurante_codRestaurante");
                resultado = new Funcionario(cpf, name,conta,cargo,dateCont,dateDemi,restaurante_codRestaurante );
                
            }
            rs.close();
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE CONSULTA: getFucionario");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
        }
        return resultado;
    }
    
    
    
    public boolean cadastrarFuncionario(Funcionario f){
        if( !conectar() ) return false;
        Funcionario resultado = null;
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            LocalDate datacont = (f.getDataContratacao());
            String sql = "INSERT INTO funcionario (cpf, nome, conta, cargo_codCargo, dataContratacao, dataDemissao, restaurante_codRestaurante)"
                    + "VALUES ("+f.getCpf()+", '"+f.getNome()+"', "+f.getConta()+", "+f.getCargo_codcargo()+", '"+datacont+"',"+null+","+f.getRestaurante_codRestaurante()+");";
            stmt.executeUpdate( sql );
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE INSERÇÃO: cadastrarFuncionario");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
            return false;
        }
        return true;
    }
    
    
    public boolean alterarFuncionario(Funcionario f){
        if( !conectar() ) return false;
            Funcionario resultado = null;
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "UPDATE Funcionario SET nome = '"+f.getNome()+"', cpf = "+f.getCpf()+", "
                    + "conta = "+f.getConta()+", cargo_codcargo = "+f.getCargo_codcargo()+" "
                    + "WHERE cpf = "+f.getCpf();
            stmt.executeUpdate( sql );
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE ATUALIZAÇÃO: alterar");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
            return false;
        }
        return true;
    }
    

    public ArrayList<Pedido> getPedidos(){
        if( !conectar() ) return null;
            ArrayList<Pedido> resultado = new ArrayList();
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "SELECT * FROM pedido";
            ResultSet rs = stmt.executeQuery( sql );
            while ( rs.next() ) {
                int comanda = rs.getInt("comanda");
                int valorprodutos = rs.getInt("valorprodutos");
                int  mesa = rs.getInt("mesa");
                long  funcionario_cpf = rs.getLong("funcionario_cpf");
                long  cliente_cpf = rs.getLong("cliente_cpf");
               
              
                resultado.add( new Pedido(comanda, valorprodutos,cliente_cpf,funcionario_cpf,mesa) );
            }
            rs.close();
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE CONSULTA: getPedidos");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
        }
        return resultado;
    }
    
    public boolean cadastrarPedido(Pedido p){
        if( !conectar() ) return false;
        Pedido resultado = null;
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "INSERT INTO pedido (comanda, valorprodutos, funcionario_cpf, cliente_cpf, mesa)"
                    + "VALUES ("+p.getComanda()+", "+p.getValorProdutos()+", "+p.getFuncionario_cpf()+", "+p.getCliente_cpf()+", "+p.getMesa()+");";
            stmt.executeUpdate( sql );
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE INSERÇÃO: cadastrarPedido");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
            return false;
        }
        return true;
    }

    public Pedido getPedido(int comanda){
        if( !conectar() ) return null;
        Pedido resultado = null;
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "SELECT * FROM Pedido WHERE comanda = "+comanda;
            ResultSet rs = stmt.executeQuery( sql );
            while ( rs.next() ) {
                               
                int  valorprodutos = rs.getInt("valorprodutos");
                int mesa  = rs.getInt("mesa");
                long funcionario_cpf  = rs.getLong("funcionario_cpf");
                long cliente_cpf  = rs.getLong("cliente_cpf"); 
                resultado = new Pedido(comanda, valorprodutos,cliente_cpf,funcionario_cpf, mesa);
                
            }
            rs.close();
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE CONSULTA: getPedido");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
        }
        return resultado;
    }
        
    public boolean alterarPedido(Pedido p){
        if( !conectar() ) return false;
            Pedido resultado = null;
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "UPDATE Pedido SET valorprodutos = "+p.getValorProdutos()+", mesa = "+p.getMesa()+", "
                    + "funcionario_cpf = "+p.getFuncionario_cpf()+", cliente_cpf = "+p.getCliente_cpf()+""
                    + "WHERE comanda = "+p.getComanda();
            stmt.executeUpdate( sql );
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE ATUALIZAÇÃO: alterar");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
            return false;
        }
        return true;
    }
    
    public ArrayList<Pagamento> getPagamentos(){
        if( !conectar() ) return null;
            ArrayList<Pagamento> resultado = new ArrayList();
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "SELECT * FROM pagamento ";
            ResultSet rs = stmt.executeQuery( sql );
            while ( rs.next() ) {
                int cartao_numcartao = rs.getInt("cartao_numcartao");
                int dinheiro_iddinheiro = rs.getInt("dinheiro_iddinheiro");
                int  pedido_comanda = rs.getInt("pedido_comanda");
                long  cliente_cpf = rs.getLong("cliente_cpf");

                
                resultado.add( new Pagamento(cartao_numcartao,cliente_cpf ,dinheiro_iddinheiro, pedido_comanda) );
            }
            rs.close();
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE CONSULTA: getPagamento");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
        }
        return resultado;
    }
   
    
    public boolean excluirPedido( Pedido p){
        if( !conectar() ) return false;
            Pedido resultado = null;
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            
            String sql = "Delete From pedido where comanda ="+p.getComanda();
            stmt.executeUpdate( sql );
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE CANCELAMENTO: Cancelar");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
            return false;
        }
        return true;
         
    }
    
    
    public boolean cadastrarReserva(Reserva r){
    if( !conectar() ) return false;
    Reserva reserva = null;
    try{
        Statement stmt = null;
        stmt = c.createStatement();
        String sql = "INSERT INTO reserva (idreserva, cliente_cpf, quantidade, data_2)"
                + "VALUES ("+r.getIdreserva()+", '"+r.getCliente_Cpf()+"', "+r.getQuantidade()+", "+r.getData_2()+");";
        stmt.executeUpdate( sql );
        stmt.close();
        c.close();
    } catch ( Exception e ) {
        System.err.println( "ERRO DURANTE INSERÇÃO: cadastrarReserva");
        System.err.println( e.getClass().getName()+": "+ e.getMessage() );
        return false;
    }
    return true;
}
        
    public Reserva getReserva(int idreserva){
        if( !conectar() ) return null;
        Reserva resultado = null;
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            String sql = "SELECT * FROM reserva WHERE idreserva = "+idreserva;
            ResultSet rs = stmt.executeQuery( sql );
            while ( rs.next() ) {

                // verificar -- 
                long  cliente_cpf  = rs.getLong("cliente_cpf");
                int quantidade  = rs.getInt("quatidade");
                LocalDate data_2  = LocalDate.parse(rs.getString("data_2")); 
                resultado = new Reserva(idreserva, cliente_cpf,quantidade,data_2);
                
            }
            rs.close();
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE CONSULTA: getReserva");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
        }
        return resultado;
    }
    
    //
    public boolean excluirReserva( Reserva r){
        if( !conectar() ) return false;
            Reserva reserva = null;
        try{
            Statement stmt = null;
            stmt = c.createStatement();
            
            String sql = "Delete From reserva where idreserva ="+r.getIdreserva();
            stmt.executeUpdate( sql );
            stmt.close();
            c.close();
        } catch ( Exception e ) {
            System.err.println( "ERRO DURANTE CANCELAMENTO: Cancelar");
            System.err.println( e.getClass().getName()+": "+ e.getMessage() );
            return false;
        }
        return true;
         
    }
}
